

def existe_arquivo(arquivo):
    from time import sleep
    try: #existe arquivo
        file = open(arquivo,'rt')
        file.close()
        print('Arquivo encontrado com sucesso!\n')
        return True
    except FileNotFoundError: #nao existe arquivo
        print('Arquivo não encontrado, criando...\n')
        sleep(2)
        try: #criação de arquivo
            file = open(arquivo,'wt')
            file.close()
            print('Arquivo criado com sucesso!\n')
            return True
        except Exception as erro: #erro na criação, modo interno
            print(f'Tipo de erro: {erro}')
            print('Erro na criação do arquivo\n')
            return False
    except Exception as erro:
        print(f'Tipo de erro: {erro}')
        print('Erro não identificado na identificação do arquivo')
        return False
        
#########################################################################################
#      Trancrever de arquivos txt via formato CSV:
def transcrever_arquivo(arquivo):
    try: #transcrever
        dicionario = {}
        file = open(arquivo,'rt')
        linhas = file.split('\n')
        #linhas = [ [isbn,dados], [isbn,dados] ]
        #dicionario = { isbn : [dados,dados] , isbn = [dados,dados] }
        for unica in linhas:
            dicionario[unica[0]] = []
            for dados in unica:
                if dados != unica[0]:
                    dicionario[unica[0]].append(dados)
        file.close()
        print('Transcrição feita com sucesso!\n')
        return dicionario
    except Exception as erro: #erro no processo
        print(f'Tipo de erro: {erro}')
        print('Erro na transcrição dos arquivos externos...\n')
        return None
########################################
#oque colocar no arquivo
# cpfs lista
# dados lista
#lista separada por virgula

def escrever_arquivo(arquivo,dicionario):
    #banco = {ISBN : [dados,dados]}
    try: #colocando
        file = open(arquivo,'wt')
        for isbn in dicionario:
            isbn += ','
            file.write(isbn)
            for dados in isbn:
                dados += ',' if dados != isbn[-1] else '\n'
                file.write(isbn)
        file.close()

    except Exception as erro: #erro no processo
        print(f'Tipo de erro: {erro}')
        print('Erro na adição dos dados para um arquivo externo...\n')
        return False
    return True

######################################################
