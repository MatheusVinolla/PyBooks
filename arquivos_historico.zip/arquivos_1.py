from time import sleep
arquivo = 'galinha.txt'

def existe_arquivo(arquivo):
    try: #existe arquivo
        file = open(arquivo,'rt')
        file.close()
        print('Arquivo encontrado com sucesso!\n')
        return True
    except FileNotFoundError: #nao existe arquivo
        print('Arquivo não encontrado, criando...\n')
        sleep(2)
        try: #criação de arquivo
            file = open(arquivo,'wt')
            file.close()
            print('Arquivo criado com sucesso!\n')
            return True
        except Exception as erro: #erro na criação, modo interno
            print(f'Tipo de erro: {erro}')
            print('Erro na criação do arquivo\n')
            return False
    except Exception as erro:
        print(f'Tipo de erro: {erro}')
        print('Erro não identificado na identificação do arquivo')
        return False
#########################################################################################

def leitura_arquivo(arquivo):
    #leitura do arquivo
    teste = []
    try: #transcrever
        file = open(arquivo,'rt')
        for e in file:
            e = e.rstrip()
            teste.append(e)
        file.close()
        print('Transcrição feita com sucesso!\n')
        return teste
    except Exception as erro: #erro no processo
        print(f'Tipo de erro: {erro}')
        print('Erro na transcrição dos arquivos externos...\n')
        return None
########################################
#oque colocar no arquivoA

def escrita_arquivo(arquivo):
    teste = []
    cont = 0
    inserir = '0'
    
    print('Digite apenas ENTER para sair...')
    while (len(inserir) != 0) or (inserir.isspace()):
        inserir = input(f'Insira o conteúdo para a {cont + 1}° linha: ')
        if (inserir.isspace()) or (len(inserir) == 0):
            print('Feito')
        else:
            teste.append(inserir)
        cont += 1
    
    try: #colocando
        file = open(arquivo,'wt')
        for e in teste:
            e = e + '\n'
            file.write(e)
        file.close()
        print('Adição feita com sucesso!\n')
        return True
    except Exception as erro: #erro no processo
        print(f'Tipo de erro: {erro}')
        print('Erro na adição dos dados para um arquivo externo...\n')
        return False
###############################################################################################

print('1° passo IDENTIFICAÇÃO CORRETA')
sucesso1 = existe_arquivo(arquivo)

print('2° passo INSCRIÇÃO CORRETA')
sucesso2 = escrita_arquivo(arquivo)

print('3° passo LEITURA CORRETA')
sucesso3 = leitura_arquivo(arquivo)

print('1 deu certo' if sucesso1 else '')
print('2 deu certo' if sucesso2 else '')
print(f'3 deu certo\n{sucesso3}' if (sucesso3 is not None) else '')

