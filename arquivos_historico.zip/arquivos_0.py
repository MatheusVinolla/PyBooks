from time import sleep
arquivo = 'galinha.txt'

def existe_arquivo():
    try: #existe arquivo
        file = open(arquivo,'rt')
        file.close()
        print('Arquivo encontrado com sucesso!\n')
    except FileNotFoundError: #nao existe arquivo
        print('Arquivo não encontrado, criando...\n')
        sleep(2)
        try: #criação de arquivo
            file = open(arquivo,'wt')
            file.close()
            print('Arquivo criado com sucesso!\n')
        except Exception as erro: #erro na criação, modo interno
            print(f'Tipo de erro: {erro}')
            print('Erro na criação do arquivo, trocando para modo de armazenamento interno...\n')
    
    except Exception as erro:
        print(f'Tipo de erro: {erro}')
        print('Erro não identificado na identificação do arquivo')
#########################################################################################

def leitura_arquivo():
    #leitura do arquivo
    teste = []
    try: #transcrever
        file = open(arquivo,'rt')
        for e in file:
            e = e.rstrip()
            teste.append(e)
        file.close()
        print('Transcrição feita com sucesso!\n')
    except Exception as erro: #erro no processo
        print(f'Tipo de erro: {erro}')
        print('Erro na transcrição dos arquivos externos...\n')

########################################
#oque colocar no arquivo

def escrita_arquivo():
    teste = []
    while inserir != '':
        inserir = input(f'Insira o conteúdo para a {}° linha')
        if inserir.isspace():
            print('Feito')
        else:
            teste.append(inserir)
    
    try: #colocando
        file = open(arquivo,'wt')
        for e in teste:
            e = e + '\n'
            file.write(e)
        file.close()
        print('Adição feita com sucesso!\n')
    except Exception as erro: #erro no processo
        print(f'Tipo de erro: {erro}')
        print('Erro na adição dos dados para um arquivo externo...\n')

###############################################################################################

















