# crud para livraria focada em administração
# crud para livro OK
# estoque OK
# crud para comprar
# -cpf do cliente
# -encontrar livro 
# -deseja comprar? s
# -livro adquirido com sucesso

# relatorio OK
# sair (durante o condicional)
#

#ISBN = lista com dados do livro
#titulo,autor,ano,preco,categoria
formulario = ['TÍTULO','AUTOR','ANO','PREÇO','CATEGORIA']
estoque_livro = {
'123' : ['Harry Potter',
        'JK Rowling','2020','23.34','Infanto-Juvenil']
}

#LIVROS
def cadastrar_livro(banco):
    global formulario
    isbn = input('Insira o ISBN do livro para cadastrar: ')
    banco[isbn] = []
    for i,e in enumerate(formulario):
        msg = f'Insira o {formulario[i]} do Livro: '
        banco[isbn].append(input(msg))

def atualizar_livro(banco):
    global formulario
    isbn = input('Insira o ISBN do livro para atualizar: ')
    if isbn in banco:
        print('Livro Encontrado')
        banco[isbn].clear()
        banco[isbn] = []
        for i,e in enumerate(formulario):
            msg = f'Insira o novo {formulario[i]} do Livro: '
            banco[isbn].append(input(msg))
        
    else:
        print('Livro não encontrado, tente novamente...')
    


def pesquisar_livro(banco):
    isbn = input('Insira o ISBN do livro para pesquisar: ')
    if isbn in banco:
        print('Livro Encontrado')
        print()
        for e in banco[isbn]:
            print(e)
        print()
    else:
        print('Livro não encontrado, tente novamente...')


def deletar_livro(banco):
    isbn = input('Insira o ISBN do livro para deletar: ')
    if isbn in banco:
        print('Livro Encontrado')
        del banco[isbn]
        print('Livro deletado com sucesso')
    else:
        print('Livro não encontrado, tente novamente...')
    

##################################################
# -cpf do cliente
# -encontrar livro 
# -deseja comprar? s
# -livro adquirido com sucesso

def cadastrar_compra(banco):
    pessoa = input('Insira o CPF do Cliente que deseja afetuar a compra: ')
    isbn = input('Insira o ISBN do Livro que deseja adquirir: ')
    if isbn in banco:
        #mostrar no indice do preço
        print('Livro Encontrado')
        print()
        for e in banco[isbn]:
            print(e)
        print()
        resp = input('Deseja adquirir essa obra?')
        if resp.upper() == 'S':
            print('Livro Adquirido com sucesso!')
        else:
            print('Ok, estou aqui caso queira...')
    else:
        print('Livro não encontrado...')
    
def total_compras(banco):
    pass
    
####################################################
def estoque(banco):
    for k,lista in banco.items():
        print(f' {lista[0]} '.center(30,'='))
        for e in lista:
            if e == lista[0]:
                print(k)
            else:
                print(e)


####################################################3
def relatorio():
    print("""\033[1m
FEITO POR: MATHEUS VINOLLA MEDEIROS E SILVA
PROJETO PARA A DISCIPLINA DE ALGORITMOS E 
LOGICA DE PROGRAMAÇÃO
LICENÇA LIVRE GUI\033[m""")

cadastrar_compra(estoque_livro)
    
    
    
    