# crud para livraria focada em administração
# crud para livro OK
# estoque OK
# crud para comprar
# -cpf do cliente
# -encontrar livro 
# -deseja comprar? s
# -livro adquirido com sucesso

# relatorio OK
# sair (durante o condicional)
#

#ISBN = lista com dados do livro
#titulo,autor,ano,preco,categoria
from os import system

formulario = ['TÍTULO','AUTOR','ANO','PREÇO','CATEGORIA']
estoque_livro = {
'123' : ['Harry Potter',
        'JK Rowling','2020','23.34','Infanto-Juvenil']
}
historico_compras = {
'123.123.123' : ['123','Harry Potter','23.34']    
}

#LIVROS
def cadastrar_livro(banco):
    global formulario
    isbn = input('Insira o ISBN do livro para cadastrar: ')
    banco[isbn] = []
    for i,e in enumerate(formulario):
        msg = f'Insira o {formulario[i]} do Livro: '
        banco[isbn].append(input(msg))

def atualizar_livro(banco):
    global formulario
    isbn = input('Insira o ISBN do livro para atualizar: ')
    if isbn in banco:
        print('Livro Encontrado')
        banco[isbn].clear()
        banco[isbn] = []
        for i,e in enumerate(formulario):
            msg = f'Insira o novo {formulario[i]} do Livro: '
            banco[isbn].append(input(msg))
        
    else:
        print('Livro não encontrado, tente novamente...')
    


def pesquisar_livro(banco):
    isbn = input('Insira o ISBN do livro para pesquisar: ')
    if isbn in banco:
        print('Livro Encontrado')
        print()
        for e in banco[isbn]:
            print(e)
        print()
    else:
        print('Livro não encontrado, tente novamente...')


def deletar_livro(banco):
    isbn = input('Insira o ISBN do livro para deletar: ')
    if isbn in banco:
        print('Livro Encontrado')
        del banco[isbn]
        print('Livro deletado com sucesso')
    else:
        print('Livro não encontrado, tente novamente...')
    

##################################################
# -cpf do cliente
# -encontrar livro 
# -deseja comprar? s
# -livro adquirido com sucesso

def cadastrar_compra(livros,banco):
    pessoa = input('Insira o CPF do Cliente que deseja afetuar a compra: ')
    isbn = input('Insira o ISBN do Livro que deseja adquirir: ')
    if isbn in livros:
        #mostrar no indice do preço
        print('Livro Encontrado')
        print()
        for e in livros[isbn]:
            print(e)
        print()
        confirmar = input('Deseja adquirir essa obra?')
        if confirmar.upper() == 'S':
            print('Livro Adquirido com sucesso!')
            banco[pessoa] = []
            banco[pessoa].append(isbn)
            banco[pessoa].append(livros[isbn][0])
            banco[pessoa].append(livros[isbn][3])
            print('E cadastrado no seu histórico de compras')
        else:
            print('Ok, estou aqui caso queira...')
    else:
        print('Livro não encontrado...')
    
def historico_compra(banco):
    pessoa = input('Insira o CPF do Cliente que deseja procurar: ')
    if pessoa in banco:
        print('Pessoa Encontrada')
        print()
        for e in banco[pessoa]:
            print(e)
        print()
    else:
        print('Pessoa não encontrada...')

def pesquisar_compra(banco):
    pessoa = input('Insira o CPF do Cliente para ver seu histórico: ')
    if pessoa in banco:
        print('Pessoa Encontrada')
        print()
        isbn = input('Insira o ISBN do livro comprado')
        if isbn in banco:
            print('Livro encontrado')
            for e in banco[pessoa][isbn]:
                print(e)
            print()
        else:
            print('Livro não encontrado...')
        
    


####################################################
def estoque(banco):
    for k,lista in banco.items():
        print(f' {lista[0]} '.center(30,'='))
        for e in lista:
            if e == lista[0]:
                print(k)
            else:
                print(e)


####################################################3
def relatorio():
    print("""\033[1m
FEITO POR: MATHEUS VINOLLA MEDEIROS E SILVA
PROJETO PARA A DISCIPLINA DE ALGORITMOS E 
LOGICA DE PROGRAMAÇÃO
LICENÇA LIVRE GUI\033[m""")

def enter():
    print()
    input('Pressione enter para continuar...') 

def limpar():
    system('cls || clear')
    
#########################################################

def menu():
    msg = input("""
====================================
|  [1] Comprar
|  [2] Estoque
|  [3] Relatórios
|  [4] Sair
|  >>> """)
    return msg
    
def menu_compra():
    msg = input("""
====================================
|  [1] Nova Compra
|  [2] Histórico
|  [3] Pesquisar
|  [4] Sair
|  >>> """)
    return msg

def menu_estoque():
    msg = input("""
====================================
|  [1] Cadastrar
|  [2] Pesquisar
|  [3] Atualizar
|  [4] Deletar
|  [5] Sair
|  >>> """)
    return msg

#################################################



resp = ''
while resp != '4':
    limpar()
    print('BEM VINDO CAPITÃO!')
    resp = menu()
    limpar()
    match resp:
        case '1': #COMPRAR
            resp_compra = ''
            while resp_compra != '3':
                limpar()
                print('Bem vindo ao modulo de compras: ')
                resp_compra = menu_compra()
                limpar()
                match resp_compra:
                    case '1': # NOVA COMPRA
                        cadastrar_compra(historico_compras)
                        enter()
                    case '2': # HISTORICO
                        historico_compra(historico_compras)
                        enter()
                    case '3': # PESQUISAR
                        pesquisar_compra(historico_compras)
                        enter()
                        
                    case '4': #SAIR
                        print('Sair foi sua escolha')
                        enter()
            
        case '2': #ESTOQUE
            resp_estoque = ''
            while resp_estoque != '5':
                limpar()
                print('Bem vindo ao sistema de estoque, oque deseja fazer?')
                resp_estoque = menu_estoque()
                limpar()
                match resp_estoque:
                    case '1': #CADASTRAR
                        cadastrar_livro(estoque_livro)
                        enter()
                    case '2': #PESQUISAR
                        pesquisar_livro(estoque_livro)
                        enter()
                    case '3': #ATUALIZAR
                        atualizar_livro(estoque_livro)
                        enter()
                    case '4': #DELETAR
                        deletar_livro(estoque_livro)
                        enter()
                    case '5':
                        print('Sair foi sua escolha')
                        enter()
                    
                    case _:
                        print('Resposta Inválida, tente novamente...')
                        enter()

        case '3': #RELATORIO
            relatorio()
            enter()
        case '4': #SAIR
            print('Obrigado e volte sempre!')
        case _: #INVALIDO
            print('Resposta Inválida, tente novamente...')
            enter()
    
    
    
    
    
    
    
    
    
    
    
    