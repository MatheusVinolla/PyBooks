# crud para livraria focada em administração
# crud para livro OK
# estoque OK
# crud para comprar
# -cpf do cliente
# -encontrar livro
# -deseja comprar? s
# -livro adquirido com sucesso

# relatorio OK
# sair (durante o condicional)
#

#AINDA PRECISO TERMINAR O CRUD DE COMPRAS QUE ESTA INCOMPLETO PARA ESSA TRANSIÇÃO COM DICIONÁRIOS

#ISBN = lista com dados do livro
#titulo,autor,ano,preco,categoria
from os import system

#MANIPULAÇÃO DE ARQUIVOS
##########################################################################################
from time import sleep
arquivo = 'galinha.txt'

def existe_arquivo(arquivo):
    try: #existe arquivo
        file = open(arquivo,'rt')
        file.close()
        print('Arquivo encontrado com sucesso!\n')
        return True
    except FileNotFoundError: #nao existe arquivo
        print('Arquivo não encontrado, criando...\n')
        sleep(2)
        try: #criação de arquivo
            file = open(arquivo,'wt')
            file.close()
            print('Arquivo criado com sucesso!\n')
            return True
        except Exception as erro: #erro na criação, modo interno
            print(f'Tipo de erro: {erro}')
            print('Erro na criação do arquivo\n')
            return False
    except Exception as erro:
        print(f'Tipo de erro: {erro}')
        print('Erro não identificado na identificação do arquivo')
        return False
#########################################################################################

def leitura_arquivo(arquivo):
    #leitura do arquivo
    teste = []
    try: #transcrever
        file = open(arquivo,'rt')
        for e in file:
            e = e.rstrip()
            teste.append(e)
        file.close()
        print('Transcrição feita com sucesso!\n')
        return teste
    except Exception as erro: #erro no processo
        print(f'Tipo de erro: {erro}')
        print('Erro na transcrição dos arquivos externos...\n')
        return None
########################################
#oque colocar no arquivoA

def escrita_arquivo(arquivo):
    teste = []
    cont = 0
    inserir = '0'
    
    print('Digite apenas ENTER para sair...')
    while (len(inserir) != 0) or (inserir.isspace()):
        inserir = input(f'Insira o conteúdo para a {cont + 1}° linha: ')
        if (inserir.isspace()) or (len(inserir) == 0):
            print('Feito')
        else:
            teste.append(inserir)
        cont += 1
    
    try: #colocando
        file = open(arquivo,'wt')
        for e in teste:
            e = e + '\n'
            file.write(e)
        file.close()
        print('Adição feita com sucesso!\n')
        return True
    except Exception as erro: #erro no processo
        print(f'Tipo de erro: {erro}')
        print('Erro na adição dos dados para um arquivo externo...\n')
        return False
###############################################################################################

print('1° passo IDENTIFICAÇÃO CORRETA')
sucesso1 = existe_arquivo(arquivo)

print('2° passo INSCRIÇÃO CORRETA')
sucesso2 = escrita_arquivo(arquivo)

print('3° passo LEITURA CORRETA')
sucesso3 = leitura_arquivo(arquivo)

print('1 deu certo' if sucesso1 else '')
print('2 deu certo' if sucesso2 else '')
print(f'3 deu certo\n{sucesso3}' if (sucesso3 is not None) else '')

###############################################################################################################


formulario_livros = ['TÍTULO','AUTOR','ANO','PREÇO','CATEGORIA']
estoque_livro = {
'123' : ['Harry Potter', 'JK Rowling','2020','23.34','Infanto-Juvenil'],
'321' : ['Intoxicação digital','August Cury','2022','33.33','Auto-ajuda']
}
#CPF -> ISBN : []
historico_compras = {
'123.123.123' : { '123' : ['123','Harry Potter','23.34'],
                  '321' : ['Intoxicação digital','August Cury','2022','33.33','Auto-ajuda']
                }   
}

formulario_clientes = ['CPF','NOME','DATA DE NASCIMENTO','EMAIL','TELEFONE']
clientes = {
'123.123.123' : ['Nome','28/01/2008','nome@gmail.com','Telefone']

}
#pelo menos 1 ponto e um @
################################################################

def tela_inicial():
    msg = (r"""
████  █   █      ████   ███   ███  █   █  ████ 
█   █  █ █       █   █ █   █ █   █ █  █  █     
████    █   ████ ████  █   █ █   █ ███    ███  
█       █        █   █ █   █ █   █ █  █      █ 
█       █        ████   ███   ███  █   █ ████  
    """)
    print(f'\033[1;33m{msg}\033[m',end='')

def tela_compra():
    msg = (r"""
 ███   ███  █   █ ████  ████   ███  ████  
█     █   █ ██ ██ █   █ █   █ █   █ █   █ 
█     █   █ █ █ █ ████  ████  █████ ████  
█     █   █ █   █ █     █  █  █   █ █  █  
 ███   ███  █   █ █     █   █ █   █ █   █ 
    """)
    print(f'\033[1;33m{msg}\033[m',end='')

def tela_estoque():
    msg = (r"""
█████  ████ █████  ███   ███  █   █ █████ 
█     █       █   █   █ █   █ █   █ █     
████   ███    █   █   █ █   █ █   █ ████  
█         █   █   █   █ █  █  █   █ █     
█████ ████    █    ███   ██ █  ███  █████ 
    """)
    print(f'\033[1;33m{msg}\033[m',end='')

def tela_cliente():
    msg = (r"""
 ███  █     ███ █████ █   █ █████ █████  ████ 
█     █      █  █     ██  █   █   █     █     
█     █      █  ████  █ █ █   █   ████   ███  
█     █      █  █     █  ██   █   █         █ 
 ███  █████ ███ █████ █   █   █   █████ ████  
    """)
    print(f'\033[1;33m{msg}\033[m',end='')

def tela_cadastrar():
    msg = (r""" _____             _              _                
/  __ \           | |            | |               
| /  \/  __ _   __| |  __ _  ___ | |_  _ __   ___  
| |     / _` | / _` | / _` |/ __|| __|| '__| / _ \ 
| \__/\| (_| || (_| || (_| |\__ \| |_ | |   | (_) |
 \____/ \__,_| \__,_| \__,_||___/ \__||_|    \___/""")
    linha = '_' * 50
    print(f'\033[1m{msg}\n{linha}\n\033[m')

def tela_atualizar():
    msg = (r"""  ___   _                  _  _                                 
 / _ \ | |                | |(_)                                
/ /_\ \| |_  _   _   __ _ | | _  ____  __ _   ___   __ _   ___  
|  _  || __|| | | | / _` || || ||_  / / _` | / __| / _` | / _ \ 
| | | || |_ | |_| || (_| || || | / / | (_| || (__ | (_| || (_) |
\_| |_/ \__| \__,_| \__,_||_||_|/___| \__,_| \___| \__,_| \___/ """)
    linha = '_' * 50
    print(f'\033[1m{msg}\n{linha}\n\033[m')


def tela_pesquisar():
    msg = (r"""______                           _                   
| ___ \                         (_)                  
| |_/ /  ___  ___   __ _  _   _  _  ___   __ _  _ __ 
|  __/  / _ \/ __| / _` || | | || |/ __| / _` || '__|
| |    |  __/\__ \| (_| || |_| || |\__ \| (_| || |   
\_|     \___||___/ \__, | \__,_||_||___/ \__,_||_|   
                      | |                            
                      |_| """)
    linha = '_' * 50
    print(f'\033[1m{msg}\n{linha}\n\033[m')



def tela_deletar():
    msg = (r"""______        _        _                
|  _  \      | |      | |               
| | | |  ___ | |  ___ | |_   __ _  _ __ 
| | | | / _ \| | / _ \| __| / _` || '__|
| |/ / |  __/| ||  __/| |_ | (_| || |   
|___/   \___||_| \___| \__| \__,_||_|""")
    linha = '_' * 50
    print(f'\033[1m{msg}\n{linha}\n\033[m')


def tela_historico():
    msg = (r""" _   _  _       _                 _              
| | | |(_)     | |               (_)             
| |_| | _  ___ | |_   ___   _ __  _   ___   ___  
|  _  || |/ __|| __| / _ \ | '__|| | / __| / _ \ 
| | | || |\__ \| |_ | (_) || |   | || (__ | (_) |
\_| |_/|_||___/ \__| \___/ |_|   |_| \___| \___/ """)
    linha = '_' * 50
    print(f'\033[1m{msg}\n{linha}\n\033[m')


##################################################################
def cadastrar_livro(banco):
    global formulario_livros
    isbn = input('Insira o ISBN do livro para cadastrar: ')
    banco[isbn] = []
    for i,e in enumerate(formulario_livros):
        msg = f'Insira o {formulario_livros[i]} do Livro: '
        banco[isbn].append(input(msg))

def atualizar_livro(banco):
    global formulario_livros
    isbn = input('Insira o ISBN do livro para atualizar: ')
    if isbn in banco:
        print('Livro Encontrado')
        banco[isbn].clear()
        banco[isbn] = []
        for i,e in enumerate(formulario_livros):
            msg = f'Insira o novo {formulario_livros[i]} do Livro: '
            banco[isbn].append(input(msg))
        
    else:
        print('Livro não encontrado, tente novamente...')
    


def pesquisar_livro(banco):
    isbn = input('Insira o ISBN do livro para pesquisar: ')
    if isbn in banco:
        print('Livro Encontrado')
        print()
        for e in banco[isbn]:
            print(e)
        print()
    else:
        print('Livro não encontrado, tente novamente...')


def deletar_livro(banco):
    isbn = input('Insira o ISBN do livro para deletar: ')
    if isbn in banco:
        print('Livro Encontrado')
        del banco[isbn]
        print('Livro deletado com sucesso')
    else:
        print('Livro não encontrado, tente novamente...')
    

##################################################
# -cpf do cliente
# -encontrar livro 
# -deseja comprar? s
# -livro adquirido com sucesso

def cadastrar_compra(livros,banco):
    pessoa = input('Insira o CPF do Cliente que deseja afetuar a compra: ')
    isbn = input('Insira o ISBN do Livro que deseja adquirir: ')
    if isbn in livros:
        print('Livro Encontrado')
        print()
        for e in livros[isbn]:
            print(e)
        print()
        confirmar = input('Deseja adquirir essa obra?')
        if confirmar.upper() == 'S':
                          #BANCO MAIOR
    #'123.123.123' : { '555' : [Harry Potter','23.34']
    #                  '222' : [outra lista de livros]      }
    #'novo' :
            #Banco Livros
    # estoque_livro = {
        #'123' : ['Harry Potter', 'JK Rowling','2020','23.34','Infanto-Juvenil']
        #'321' : ['Intoxicação digital','August Cury','2022','33.33','Auto-ajuda']
         #             } 
        ##############FALTA TERMINAR
            print('Livro Adquirido com sucesso!')
            banco[pessoa] = {}
            banco[pessoa][isbn] = []
            banco[pessoa][isbn].append(livros[isbn][0])
            banco[pessoa][isbn].append(livros[isbn][3])
            print('E cadastrado no seu histórico de compras')
        else:
            print('Ok, estou aqui caso queira...')
    else:
        print('Livro não encontrado...')
    
def historico_compra(banco):
    pessoa = input('Insira o CPF do Cliente que deseja procurar: ')
    if pessoa in banco:
        print('Pessoa Encontrada')
        print()
         #'123.123.123' : { '555' : [Harry Potter','23.34']
        #                  '222' : [outra lista de livros]      }     
        for k,v in banco[pessoa].items():
            print(k,v)
        print()
    else:
        print('Pessoa não encontrada...')

def pesquisar_compra(banco):
    pessoa = input('Insira o CPF do Cliente para ver seu histórico: ')
    if pessoa in banco:
        print('Pessoa Encontrada')
        print()
        isbn = input('Insira o ISBN do livro comprado: ')
        achou = False
        #FAALTA TERMINAR
        #'123.123.123' : { '555' : [Harry Potter','23.34']
        #                  '222' : [outra lista de livros]      }     
        for e in banco[pessoa].keys():
            if e == isbn:
                achou = True
        if achou:
            print(banco[pessoa][isbn])          
        else:
            print('ISBN não encontrado tente novamente...')
        print()
    else:
        print('Livro não encontrado...')
        
####################################
#CPF : [cpf,nome,data,email,telefone]
#clientes = {'123.123.123' : ['Nome','28/01/2008','nome@gmail.com','Telefone']

def cadastrar_cliente(banco):
    global formulario_clientes
    dados = []
    for e in formulario_clientes:
        dados.append(input(f'Insira o {e} do cliente: '))
    banco[dados[0]] = [] #dessa forma eu evito que todo o loop
    for e in dados[1:]:  #faça uma verificação
        banco[dados[0]].append(e)

def pesquisar_cliente(banco):
    cliente = input('Insira o CPF do cliente para pesquisar: ')
    if cliente in banco:
        print('Cliente encontrado!')
        print()
        for e in banco[cliente]:
            print(e)
    else:
        print('Cliente não encontrado, tente novamente...')
        
def deletar_cliente(banco):
    cliente = input('Insira o CPF do cliente para deletar: ')
    if cliente in banco:
        print('Cliente encontrado!')
        del banco[cliente]
        print('Cliente deletado com sucesso!')
    else:
        print('Cliente não encontrado, tente novamente...')

def atualizar_cliente(banco):
    global formulario_clientes
    cliente = input('Insira o CPF do cliente para atualizar: ')
    if cliente in banco:
        print('Cliente encontrado!')
        del banco[cliente]
        dados = []
        for e in formulario_clientes:
            dados.append(input(f'Insira o {e} novo do cliente: '))
        banco[dados[0]] = [] #dessa forma eu evito que todo o loop
        for e in dados[1:]:  #faça uma verificação
            banco[dados[0]].append(e)
    else:
        print('Cliente não encontrado, tente novamente...')

####################################################
def estoque(banco):
    for k,lista in banco.items():
        print(f' {lista[0]} '.center(30,'='))
        for e in lista:
            if e == lista[0]:
                print(k)
            else:
                print(e)


####################################################
def relatorio():
    print("""\033[1m
FEITO POR: MATHEUS VINOLLA MEDEIROS E SILVA
PROJETO PARA A DISCIPLINA DE ALGORITMOS E 
LOGICA DE PROGRAMAÇÃO
LICENÇA LIVRE GUI\033[m""")

def enter():
    print()
    input('Pressione enter para continuar...') 

def limpar():
    system('cls || clear')
    
#########################################################

def menu():
    tela_inicial()
    msg = input(f"""\033[1;33m
{'='*50}
|  [1] Comprar
|  [2] Estoque
|  [3] Clientes
|  [4] Relatórios
|  [5] Sair
|  >>> \033[m""")
    return msg
    
def menu_compra():
    msg = input(f"""\033[1;33m
{'='*50}
|  [1] Nova Compra
|  [2] Histórico
|  [3] Pesquisar
|  [4] Sair
|  >>>\033[m """)
    return msg

def menu_estoque():
    msg = input(f"""\033[1;33m
{'='*50}
|  [1] Cadastrar Livro
|  [2] Pesquisar Livro
|  [3] Atualizar Livro
|  [4] Deletar   Livro
|  [5] Sair
|  >>> \033[m""")
    return msg

def menu_cliente():
    msg = input(f"""\033[1;33m
{'='*50}
|  [1] Cadastrar Cliente
|  [2] Pesquisar Cliente
|  [3] Atualizar Cliente
|  [4] Deletar   Cliente
|  [5] Sair
|  >>> \033[m""")
    return msg

#################################################



resp = ''
while resp != '5':
    limpar()
    resp = menu()
    limpar()
    match resp:
        case '1': #COMPRAR
            resp_compra = ''
            while resp_compra != '4':
                limpar()
                tela_compra()
                print('\r\t\n\033[1;33mBem-vindo ao Módulo de Compras\033[m')
                resp_compra = menu_compra()
                limpar()
                match resp_compra:
                    case '1': # NOVA COMPRA
                        tela_cadastrar()
                        cadastrar_compra(estoque_livro,historico_compras)
                        enter()
                    case '2': # HISTORICO
                        tela_historico()
                        historico_compra(historico_compras)
                        enter()
                    case '3': # PESQUISAR
                        tela_pesquisar()
                        pesquisar_compra(historico_compras)
                        enter()
                    case '4': #SAIR
                        print('Sair foi sua escolha')
                        enter()
            
        case '2': #ESTOQUE
            resp_estoque = ''
            while resp_estoque != '5':
                limpar()
                tela_estoque()
                print('\r\t\n\033[1;33mBem-vindo ao Módulo de Estoque\033[m')
                resp_estoque = menu_estoque()
                limpar()
                match resp_estoque:
                    case '1': #CADASTRAR
                        tela_cadastrar()
                        cadastrar_livro(estoque_livro)
                        enter()
                    case '2': #PESQUISAR
                        tela_pesquisar()
                        pesquisar_livro(estoque_livro)
                        enter()
                    case '3': #ATUALIZAR
                        tela_atualizar()
                        atualizar_livro(estoque_livro)
                        enter()
                    case '4': #DELETAR
                        tela_deletar()
                        deletar_livro(estoque_livro)
                        enter()
                    case '5':
                        print('Sair foi sua escolha')
                        enter()
                    
                    case _:
                        print('Resposta Inválida, tente novamente...')
                        enter()
        
        case '3': #CLIENTES
            resp_cliente = ''
            while resp_cliente != '5':
                limpar()
                tela_cliente()
                print('\r\t\n\033[1;33mBem-vindo ao Módulo de Clientes\033[m')
                resp_cliente = menu_cliente()
                limpar()
                match (resp_cliente):
                    case '1': #CADASTRAR
                        tela_cadastrar()
                        cadastrar_cliente(clientes)
                        enter()
                    case '2': #PESQUISAR
                        tela_pesquisar()
                        pesquisar_cliente(clientes)
                        enter()
                    case '3': #ATUALIZAR
                        tela_atualizar()
                        atualizar_cliente(clientes)
                        enter()
                    case '4': #DELETAR
                        tela_deletar()
                        deletar_cliente(clientes)
                        enter()
                    case '5': 
                        print('Sair foi sua escolha')
                        enter()
                    case _:  
                        print('Resposta Inválida, tente novamente...')
                        enter()                                  
        case '4': #RELATORIO
            relatorio()
            enter()
    
        case '5':
            print('Obrigado e volte sempre!')
        case _: #INVALIDO
            print('Resposta Inválida, tente novamente...')
            enter()
    
    
    
    
    
    